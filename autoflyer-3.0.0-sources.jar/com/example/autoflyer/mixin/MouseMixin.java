package com.example.autoflyer.mixin;

import com.example.autoflyer.HudButton;
import com.example.autoflyer.gui.SettingsScreen;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Bat su kien click chuot khi dang o trong game (khong mo GUI nao) de xac dinh
 * nguoi choi co bam vao nut "Cai dat" o goc tren ben phai hay khong.
 */
@Mixin(class_312.class)
public class MouseMixin {

    @Shadow private double x;
    @Shadow private double y;

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void autoflyer$onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1755 != null) return; // co GUI khac dang mo thi bo qua
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || action != GLFW.GLFW_PRESS) return;

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        double scaledX = this.x * screenWidth / client.method_22683().method_4480();
        double scaledY = this.y * screenHeight / client.method_22683().method_4507();

        if (HudButton.isInside(screenWidth, scaledX, scaledY)) {
            client.method_1507(new SettingsScreen(null));
            ci.cancel();
        }
    }
}
