package com.example.autoflyer.mixin;

import com.example.autoflyer.gui.SettingsScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Them 1 nut nho "Auto Flyer" vao goc tren ben trai man hinh Pause (bam ESC),
 * bam vao mo thang man hinh cai dat, khong can vao Mods/ModMenu.
 */
@Mixin(class_433.class)
public abstract class GameMenuScreenMixin extends class_437 {

    protected GameMenuScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void autoflyer$addButton(CallbackInfo ci) {
        class_433 self = (class_433) (Object) this;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Auto Flyer"), b -> {
                    class_310 client = class_310.method_1551();
                    client.method_1507(new SettingsScreen(self));
                })
                .method_46434(10, 10, 90, 20)
                .method_46431());
    }
}
