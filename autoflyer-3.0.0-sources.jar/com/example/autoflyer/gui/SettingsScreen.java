package com.example.autoflyer.gui;

import com.example.autoflyer.AutoFlyerConfig;
import com.example.autoflyer.litematica.LitematicaNavigator;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Man hinh cai dat Auto Flyer v3 - chi con 1 chuc nang duy nhat: Auto Build theo Litematica.
 * Tu dong tim block con thieu (trong lop dang hien cua Litematica) gan nguoi choi nhat,
 * bay den ngay phia tren no de mod print (vd Meteor Litematica Printer) tu dat block.
 */
public class SettingsScreen extends class_437 {
    private final class_437 parent;
    private final AutoFlyerConfig cfg = AutoFlyerConfig.INSTANCE;

    private class_342 hoverHeightField;
    private class_342 speedField;
    private class_4185 startPauseButton;

    public SettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Auto Flyer - Auto Build"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int fieldHeight = 20;
        int y = 70;

        hoverHeightField = new class_342(this.field_22793, centerX - 90, y, 70, fieldHeight, class_2561.method_43470("Do cao"));
        hoverHeightField.method_1880(6);
        hoverHeightField.method_1890(s -> s.isEmpty() || s.matches("\\d*(\\.\\d*)?"));
        hoverHeightField.method_1852(String.valueOf(cfg.litematicaHoverHeight));
        method_37063(hoverHeightField);

        speedField = new class_342(this.field_22793, centerX + 20, y, 70, fieldHeight, class_2561.method_43470("Toc do"));
        speedField.method_1880(6);
        speedField.method_1890(s -> s.isEmpty() || s.matches("\\d*(\\.\\d*)?"));
        speedField.method_1852(String.valueOf(cfg.litematicaSpeed));
        method_37063(speedField);

        startPauseButton = class_4185.method_46430(
                class_2561.method_43470(LitematicaNavigator.isRunning() ? "Pause" : "Start"),
                b -> toggleStart()
        ).method_46434(centerX - 60, this.field_22790 / 2 + 40, 120, 20).method_46431();
        method_37063(startPauseButton);
    }

    private void toggleStart() {
        saveFieldsToConfig();

        if (LitematicaNavigator.isRunning()) {
            LitematicaNavigator.stop();
            startPauseButton.method_25355(class_2561.method_43470("Start"));
        } else {
            LitematicaNavigator.start();
            startPauseButton.method_25355(class_2561.method_43470(LitematicaNavigator.isRunning() ? "Pause" : "Start"));
        }
    }

    private void saveFieldsToConfig() {
        cfg.litematicaHoverHeight = hoverHeightField != null && !hoverHeightField.method_1882().isEmpty()
                ? Double.parseDouble(hoverHeightField.method_1882()) : 2.0;
        cfg.litematicaSpeed = speedField != null && !speedField.method_1882().isEmpty()
                ? Double.parseDouble(speedField.method_1882()) : 0.8;
        cfg.save();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFF);
        context.method_27534(this.field_22793, class_2561.method_43470("Do cao bay tren block (y+)"), this.field_22789 / 2 - 90, 58, 0xAAAAAA);
        context.method_27534(this.field_22793, class_2561.method_43470("Toc do bay"), this.field_22789 / 2 + 55, 58, 0xAAAAAA);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Tu dong tim block con thieu (theo lop dang hien trong Litematica) va bay den."),
                this.field_22789 / 2, 105, 0x88CCFF);
        context.method_27534(this.field_22793,
                class_2561.method_43470("Dung ngay tren block cho mod print dat xong roi tu bay tiep."),
                this.field_22789 / 2, 120, 0x88CCFF);

        if (!FabricLoader.getInstance().isModLoaded("litematica")) {
            context.method_27534(this.field_22793,
                    class_2561.method_43470("CANH BAO: khong tim thay mod Litematica dang cai!"),
                    this.field_22789 / 2, 140, 0xFF5555);
        }
    }

    @Override
    public void method_25419() {
        saveFieldsToConfig();
        if (this.field_22787 != null) this.field_22787.method_1507(parent);
    }
}
