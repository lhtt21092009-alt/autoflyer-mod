package com.example.autoflyer;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Ve 1 nut nho o goc tren ben phai man hinh khi dang choi (khong co GUI nao mo).
 * MouseMixin se dung getBounds() de kiem tra click co trung nut nay khong.
 */
public final class HudButton {
    public static final int WIDTH = 70;
    public static final int HEIGHT = 16;
    public static final int MARGIN = 6;

    private HudButton() {}

    public static int getX(int screenWidth) {
        return screenWidth - WIDTH - MARGIN;
    }

    public static int getY() {
        return MARGIN;
    }

    public static boolean isInside(int screenWidth, double mouseX, double mouseY) {
        int x = getX(screenWidth);
        int y = getY();
        return mouseX >= x && mouseX <= x + WIDTH && mouseY >= y && mouseY <= y + HEIGHT;
    }

    /** Goi tu HudRenderCallback. */
    public static void render(class_332 context) {
        class_310 client = class_310.method_1551();
        if (client.field_1755 != null) return; // chi hien khi khong co GUI nao mo

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();
        int x = getX(screenWidth);
        int y = getY();

        double scaledMouseX = client.field_1729.method_1603() * screenWidth / client.method_22683().method_4480();
        double scaledMouseY = client.field_1729.method_1604() * screenHeight / client.method_22683().method_4507();
        boolean hovered = isInside(screenWidth, scaledMouseX, scaledMouseY);

        int bg = hovered ? 0xAA555555 : 0xAA000000;
        context.method_25294(x, y, x + WIDTH, y + HEIGHT, bg);
        context.method_49601(x, y, WIDTH, HEIGHT, 0xFFFFFFFF);
        context.method_27534(client.field_1772, class_2561.method_43470("Auto Build"),
                x + WIDTH / 2, y + (HEIGHT - 8) / 2, 0xFFFFFF);
    }
}
