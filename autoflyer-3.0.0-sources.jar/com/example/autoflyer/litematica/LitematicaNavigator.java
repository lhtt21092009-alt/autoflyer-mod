package com.example.autoflyer.litematica;

import com.example.autoflyer.AutoFlyerConfig;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Tu dong bay den tung block con thieu theo ban ve Litematica dang tai (chi trong lop dang hien),
 * dung ngay phia tren no (y + hoverHeight) de mod print (vd Meteor Litematica Printer) tu dat block.
 *
 * De tranh bay xuyen tuong khi dang xay dang map art 3D, duong bay chia lam 3 doan theo truc
 * thay vi bay thang (cheo) toi diem dich:
 *   1) ASCEND  - bay thang len do cao an toan (tren dinh toan bo cong trinh)
 *   2) TRAVEL  - bay ngang (X/Z) toi ngay phia tren diem dich, van o do cao an toan
 *   3) DESCEND - ha thang xuong diem dich (x, y+hoverHeight, z)
 * Neu duong bay thang toi dich khong bi vuong block nao (kiem tra bang isPathClear), se bay
 * thang toi luon cho nhanh (dung yeu cau "bay nhanh nhat co the").
 */
public class LitematicaNavigator {
    private enum Phase { ASCEND, TRAVEL, DESCEND, HOVER, DIRECT }

    private static boolean running = false;
    private static class_2338 currentTarget = null;
    private static Phase phase = null;
    private static double cruiseY;

    private static class_243 lastPos = null;
    private static int stuckTicks = 0;
    private static int hoverTicks = 0;
    private static int retries = 0;

    // Vi tri vua "cho qua lau ma van chua duoc dat" se bi tam thoi bo qua, tranh ket o 1 cho.
    private static final Map<class_2338, Long> skipUntilTick = new HashMap<>();
    private static long tickCounter = 0;

    private static final int HOVER_TIMEOUT_TICKS = 100;   // 5 giay cho printer dat block
    private static final int STUCK_TIMEOUT_TICKS = 40;    // 2 giay khong nhuc nhich -> coi la vuong
    private static final int MAX_RETRIES_BEFORE_SKIP = 3;
    private static final int SEARCH_HARD_CAP = 400_000;   // an toan hieu nang khi quet vung lon

    public static boolean isRunning() {
        return running;
    }

    public static void start() {
        if (!LitematicaBridge.isLitematicaLoaded()) {
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
                client.field_1724.method_7353(class_2561.method_43470("Auto Flyer: khong tim thay mod Litematica, khong the dung che do nay."), false);
            }
            return;
        }
        running = true;
        currentTarget = null;
        phase = null;
        stuckTicks = 0;
        hoverTicks = 0;
        retries = 0;
        lastPos = null;
    }

    public static void stop() {
        running = false;
        currentTarget = null;
        phase = null;
        class_746 player = class_310.method_1551().field_1724;
        if (player != null) {
            player.method_18800(0, 0, 0);
        }
    }

    public static void tick(class_310 client) {
        if (!running) return;
        tickCounter++;

        class_746 player = client.field_1724;
        class_638 world = client.field_1687;
        if (player == null || world == null) {
            stop();
            return;
        }

        AutoFlyerConfig cfg = AutoFlyerConfig.INSTANCE;

        // Chon block dich moi neu chua co, hoac block cu da duoc dat xong roi
        if (currentTarget == null || LitematicaBridge.isPlacedCorrectly(world, currentTarget)) {
            if (currentTarget != null) {
                skipUntilTick.remove(currentTarget); // da xong, khong can skip nua
            }
            cleanupExpiredSkips();

            currentTarget = LitematicaBridge.findNearestMissingBlock(world, player.method_19538(), skipUntilTick.keySet(), SEARCH_HARD_CAP);
            if (currentTarget == null) {
                player.method_7353(class_2561.method_43470("Auto Flyer: khong con block nao con thieu trong lop dang hien - da xong!"), false);
                stop();
                return;
            }

            phase = null; // se tinh lai duong bay ben duoi
            hoverTicks = 0;
            retries = 0;
        }

        class_243 hoverTarget = new class_243(
                currentTarget.method_10263() + 0.5,
                currentTarget.method_10264() + cfg.litematicaHoverHeight,
                currentTarget.method_10260() + 0.5
        );

        if (phase == null) {
            phase = choosePath(world, player.method_19538(), hoverTarget);
        }

        class_243 current = player.method_19538();
        double moveSpeed = Math.max(cfg.litematicaSpeed, 0.1);

        switch (phase) {
            case DIRECT -> {
                if (flyToward(player, hoverTarget, moveSpeed)) {
                    phase = Phase.HOVER;
                }
            }
            case ASCEND -> {
                class_243 ascendTarget = new class_243(current.field_1352, cruiseY, current.field_1350);
                if (flyToward(player, ascendTarget, moveSpeed)) {
                    phase = Phase.TRAVEL;
                }
            }
            case TRAVEL -> {
                class_243 travelTarget = new class_243(hoverTarget.field_1352, cruiseY, hoverTarget.field_1350);
                if (flyToward(player, travelTarget, moveSpeed)) {
                    phase = Phase.DESCEND;
                }
            }
            case DESCEND -> {
                if (flyToward(player, hoverTarget, moveSpeed)) {
                    phase = Phase.HOVER;
                }
            }
            case HOVER -> {
                player.method_18800(0, 0, 0);
                hoverTicks++;
                if (hoverTicks > HOVER_TIMEOUT_TICKS) {
                    // Cho qua lau ma van chua thay dat -> bo qua tam thoi, sang block khac
                    skipUntilTick.put(currentTarget, tickCounter + 200); // ~10 giay
                    currentTarget = null;
                }
            }
        }

        // Phat hien bi ket (vuong tuong) trong luc dang bay (khong tinh luc HOVER)
        if (phase != Phase.HOVER) {
            if (lastPos != null && current.method_1025(lastPos) < 0.02 * 0.02) {
                stuckTicks++;
            } else {
                stuckTicks = 0;
            }

            if (stuckTicks > STUCK_TIMEOUT_TICKS) {
                stuckTicks = 0;
                retries++;
                if (retries > MAX_RETRIES_BEFORE_SKIP) {
                    // Thu vai lan van khong toi duoc -> bo qua block nay, tim block khac
                    skipUntilTick.put(currentTarget, tickCounter + 200);
                    currentTarget = null;
                } else {
                    // Thu lai voi do cao an toan hon (bay len cao them)
                    cruiseY += 6;
                    phase = Phase.ASCEND;
                }
            }
        }

        lastPos = current;
    }

    /**
     * Chon duong bay: neu duong thang toi dich khong bi vuong thi bay thang (nhanh nhat).
     * Neu bi vuong, DO TIM do cao thap nhat vua du de bay vong qua (tang dan tung buoc nho),
     * thay vi luon bay len tan dinh cao nhat cua ca cong trinh - tranh ton thoi gian khi vat can
     * chi la 1 khoi nho gan do.
     */
    private static Phase choosePath(class_638 world, class_243 from, class_243 to) {
        if (isPathClear(world, from, to)) {
            return Phase.DIRECT;
        }

        int buildTop = LitematicaBridge.getHighestEnabledPlacementTop();
        double baseY = Math.max(from.field_1351, to.field_1351);
        double capY = Math.max(buildTop + 5, baseY + 3); // gioi han tren cung, phong khi khong tim duoc cho nao thap hon

        // Dò tang dan tung 2 block 1, tim do cao THAP NHAT ma ca 3 doan (len - ngang - xuong) deu thong thoang
        for (double candidateY = baseY + 2; candidateY <= capY; candidateY += 2) {
            class_243 ascendPoint = new class_243(from.field_1352, candidateY, from.field_1350);
            class_243 travelPoint = new class_243(to.field_1352, candidateY, to.field_1350);

            if (isPathClear(world, from, ascendPoint)
                    && isPathClear(world, ascendPoint, travelPoint)
                    && isPathClear(world, travelPoint, to)) {
                cruiseY = candidateY;
                return Phase.ASCEND;
            }
        }

        // Khong tim duoc cho nao thap hon thong thoang -> danh phai bay len tan dinh cong trinh
        cruiseY = capY;
        return Phase.ASCEND;
    }

    /** Kiem tra doan thang tu 'from' toi 'to' co bi block dac chan khong (danh gia don gian, khong phai raytrace vat ly that). */
    private static boolean isPathClear(class_638 world, class_243 from, class_243 to) {
        double distance = from.method_1022(to);
        if (distance < 0.1) return true;

        int steps = (int) Math.ceil(distance / 0.5);
        for (int i = 1; i < steps; i++) {
            double t = (double) i / steps;
            double x = from.field_1352 + (to.field_1352 - from.field_1352) * t;
            double y = from.field_1351 + (to.field_1351 - from.field_1351) * t;
            double z = from.field_1350 + (to.field_1350 - from.field_1350) * t;
            class_2338 pos = class_2338.method_49637(x, y, z);
            class_2680 state = world.method_8320(pos);
            if (!state.method_26215() && !state.method_26220(world, pos).method_1110()) {
                return false;
            }
        }
        return true;
    }

    /** Bay ve phia target voi toc do cho truoc. Tra ve true neu da toi noi. */
    private static boolean flyToward(class_746 player, class_243 target, double speed) {
        class_243 current = player.method_19538();
        class_243 diff = target.method_1020(current);
        double distance = diff.method_1033();

        if (distance < 0.4) {
            player.method_18800(0, 0, 0);
            return true;
        }

        if (!player.method_31549().field_7479 && player.method_31549().field_7478) {
            player.method_31549().field_7479 = true;
            player.method_7355();
        }

        double moveAmount = Math.min(speed, distance);
        class_243 direction = diff.method_1029();
        player.method_18799(direction.method_1021(moveAmount));

        float yaw = (float) Math.toDegrees(Math.atan2(-direction.field_1352, direction.field_1350));
        float pitch = (float) Math.toDegrees(-Math.asin(direction.field_1351));
        player.method_36456(yaw);
        player.method_36457(pitch);
        player.field_6037 = true;

        return false;
    }

    private static void cleanupExpiredSkips() {
        Set<class_2338> expired = new HashSet<>();
        for (Map.Entry<class_2338, Long> e : skipUntilTick.entrySet()) {
            if (e.getValue() <= tickCounter) expired.add(e.getKey());
        }
        for (class_2338 pos : expired) skipUntilTick.remove(pos);
    }
}
